window.genesisMovies = [
    {
        id: "gen001",
        title: "A Criação do Mundo",
        description: "A história dos sete dias da criação",
        category: "Gênesis",
        poster: "https://placeholder.com/300x400",
        videoUrl: "https://example.com/videos/creation.mp4"
    },
    {
        id: "gen002",
        title: "O Jardim do Éden",
        description: "O paraíso criado por Deus para Adão e Eva",
        category: "Gênesis",
        poster: "https://placeholder.com/300x400",
        videoUrl: "https://example.com/videos/eden.mp4"
    },
    // ... rest of Genesis movies remain the same
];
